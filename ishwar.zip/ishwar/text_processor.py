"""
Text processing and NLP utilities for the News Authenticity Detector.
"""

import re
from typing import List, Set, Dict, Tuple
import string
from collections import Counter

class TextProcessor:
    """
    Text processing and NLP utilities.
    """
    
    def __init__(self):
        """
        Initialize the text processor.
        """
        # English stop words
        self.stop_words = set([
            'a', 'an', 'the', 'and', 'but', 'or', 'for', 'nor', 'on', 'at', 'to', 'by',
            'in', 'of', 'with', 'is', 'was', 'were', 'be', 'been', 'being', 'am', 'are',
            'this', 'that', 'these', 'those', 'it', 'they', 'them', 'their', 'from',
            'have', 'has', 'had', 'having', 'do', 'does', 'did', 'doing', 'would', 'should',
            'could', 'will', 'shall', 'may', 'might', 'must', 'can'
        ])
    
    def tokenize(self, text: str) -> List[str]:
        """
        Tokenize text into words.
        
        Args:
            text: Text to tokenize
            
        Returns:
            List of tokens
        """
        # Convert to lowercase and tokenize
        text = text.lower()
        # Remove punctuation
        text = re.sub(f'[{re.escape(string.punctuation)}]', ' ', text)
        # Split by whitespace
        tokens = text.split()
        return tokens
    
    def extract_keywords(self, text: str, top_n: int = 10) -> List[str]:
        """
        Extract important keywords from text.
        
        Args:
            text: Text to extract keywords from
            top_n: Number of top keywords to return
            
        Returns:
            List of keywords
        """
        # Tokenize
        tokens = self.tokenize(text)
        # Remove stop words
        tokens = [t for t in tokens if t not in self.stop_words and len(t) > 2]
        # Count frequencies
        counter = Counter(tokens)
        # Get top words
        top_words = [word for word, _ in counter.most_common(top_n)]
        return top_words
    
    def extract_named_entities(self, text: str) -> List[str]:
        """
        Extract named entities from text.
        This is a simplified version that looks for capitalized phrases.
        
        Args:
            text: Text to extract entities from
            
        Returns:
            List of potential named entities
        """
        # Look for phrases that start with a capital letter
        entity_pattern = r'\b[A-Z][a-zA-Z]*(?:\s+[A-Z][a-zA-Z]*)*\b'
        entities = re.findall(entity_pattern, text)
        # Filter out single-word common words that might be capitalized at start of sentence
        entities = [e for e in entities if len(e.split()) > 1 or e not in self.stop_words]
        return entities
    
    def text_similarity(self, text1: str, text2: str) -> float:
        """
        Calculate the similarity between two texts using Jaccard similarity.
        
        Args:
            text1: First text
            text2: Second text
            
        Returns:
            Similarity score between 0 and 1
        """
        # Tokenize both texts
        tokens1 = set(self.tokenize(text1))
        tokens2 = set(self.tokenize(text2))
        
        # Remove stop words
        tokens1 = {t for t in tokens1 if t not in self.stop_words}
        tokens2 = {t for t in tokens2 if t not in self.stop_words}
        
        # Jaccard similarity
        if not tokens1 or not tokens2:
            return 0.0
        
        intersection = len(tokens1.intersection(tokens2))
        union = len(tokens1.union(tokens2))
        
        return intersection / union
    
    def summarize_text(self, text: str, sentences: int = 3) -> str:
        """
        Create a simple extractive summary of text.
        
        Args:
            text: Text to summarize
            sentences: Number of sentences to include in summary
            
        Returns:
            Summarized text
        """
        # Split into sentences
        sentence_pattern = r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?|\!)\s'
        all_sentences = re.split(sentence_pattern, text)
        
        # Score sentences by word importance
        sentence_scores = {}
        for i, sentence in enumerate(all_sentences):
            words = self.tokenize(sentence)
            # Score is based on number of non-stop words
            score = len([w for w in words if w not in self.stop_words])
            # Give higher score to sentences at the beginning
            if i < len(all_sentences) * 0.2:  # First 20% of sentences
                score *= 1.5
            sentence_scores[i] = score
        
        # Get top sentences
        top_indices = sorted(sentence_scores, key=sentence_scores.get, reverse=True)[:sentences]
        # Sort indices to maintain original order
        top_indices = sorted(top_indices)
        
        # Construct summary
        summary = ' '.join([all_sentences[i] for i in top_indices])
        return summary
