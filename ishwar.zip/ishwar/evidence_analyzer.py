"""
Evidence analysis module for the News Authenticity Detector.
This module provides functionality to analyze evidence and determine the veracity of claims.
"""

from groq import Groq
import re
import os
from typing import List, Dict, Tuple, Optional
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

class EvidenceAnalyzer:
    """
    Analyzes evidence to determine if a claim is supported, refuted, or has no clear evidence.
    """
    
    def __init__(self, ai_model: str = "llama3-70b-8192"):
        """
        Initialize the evidence analyzer.
        
        Args:
            ai_model: AI model to use for analysis (defaults to llama3-70b-8192)
        """
        self.ai_model = ai_model
        # Configure Groq API
        self.client = Groq(api_key=os.getenv('GROQ_API_KEY'))
    
    def analyze(self, claim: str, evidence: List[Dict]) -> Tuple[str, str]:
        """
        Analyze evidence to determine if a claim is supported, refuted, or has no clear evidence.
        
        Args:
            claim: The claim being evaluated
            evidence: List of dictionaries containing evidence
            
        Returns:
            Tuple of (verdict, explanation)
        """
        # Format the evidence for the AI prompt
        evidence_text = ""
        for i, e in enumerate(evidence, 1):
            evidence_text += f"SOURCE {i}: {e['title']} from {e['source']}\n"
            evidence_text += f"{e['content'][:500]}...\n\n"
        
        # Create the prompt for the AI
        prompt = f"""
        CLAIM: {claim}
        
        RELATED ARTICLES:
        {evidence_text}
        
        Based ONLY on the information in the RELATED ARTICLES above (not your general knowledge),
        determine if the claim is supported, refuted, or if there is no clear evidence.
        
        First, analyze each piece of evidence to see if it directly addresses the claim.
        Second, determine if the evidence supports or refutes the claim, or if it's inconclusive.
        Finally, provide a short, neutral explanation summarizing the key evidence.
          VERDICT: (Choose one: Supported / Refuted / No clear evidence)
        EXPLANATION: (One or two neutral sentences explaining the verdict)
        """
        
        try:
            # Use Groq API for analysis
            response = self.client.chat.completions.create(
                model=self.ai_model,
                messages=[
                    {"role": "system", "content": "You are an objective fact-checking assistant that only uses the provided sources to verify claims."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=500
            )
            
            result = response.choices[0].message.content
            
            # Parse the result to extract verdict and explanation
            if "VERDICT: Supported" in result:
                verdict = "Supported"
            elif "VERDICT: Refuted" in result:
                verdict = "Refuted"
            else:
                verdict = "No clear evidence"
            
            # Extract explanation
            explanation_match = re.search(r"EXPLANATION:(.+?)(?=SOURCES:|$)", result, re.DOTALL)
            if explanation_match:
                explanation = explanation_match.group(1).strip()
            else:
                explanation_lines = [line for line in result.split('\n') if line and 'VERDICT:' not in line]
                explanation = ' '.join(explanation_lines).strip()
                if len(explanation) > 300:
                    explanation = explanation[:297] + '...'
            
            return verdict, explanation
            
        except Exception as e:
            print(f"Error analyzing evidence with Groq: {e}")
            return "No clear evidence", f"An error occurred while analyzing the evidence: {str(e)}"
    
    def analyze_with_detail(self, claim: str, evidence: List[Dict]) -> Dict:
        """
        Analyze evidence with detailed reasoning for each piece of evidence.
        
        Args:
            claim: The claim being evaluated
            evidence: List of dictionaries containing evidence
            
        Returns:
            Dictionary with verdict, explanation, and detailed analysis
        """
        # Format the evidence for the AI prompt
        evidence_text = ""
        for i, e in enumerate(evidence, 1):
            evidence_text += f"SOURCE {i}: {e['title']} from {e['source']}\n"
            evidence_text += f"{e['content'][:500]}...\n\n"
        
        # Create the prompt for the AI
        prompt = f"""
        CLAIM: {claim}
        
        RELATED ARTICLES:
        {evidence_text}
        
        Based ONLY on the information in the RELATED ARTICLES above (not your general knowledge),
        determine if the claim is supported, refuted, or if there is no clear evidence.
        
        For each source, provide a brief analysis of how it relates to the claim.
        Then provide an overall verdict and explanation.
        
        Format your response like this:
        
        SOURCE 1 ANALYSIS: (Brief analysis of source 1)        SOURCE 2 ANALYSIS: (Brief analysis of source 2)
        ...
        
        VERDICT: (Choose one: Supported / Refuted / No clear evidence)
        EXPLANATION: (One or two neutral sentences explaining the verdict)
        """
        try:
            # Use Groq API for analysis
            response = self.client.chat.completions.create(
                model=self.ai_model,
                messages=[
                    {"role": "system", "content": "You are an objective fact-checking assistant that only uses the provided sources to verify claims."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1000
            )
            
            result = response.choices[0].message.content
            
            # Parse the result to extract verdict and explanation
            if "VERDICT: Supported" in result:
                verdict = "Supported"
            elif "VERDICT: Refuted" in result:
                verdict = "Refuted"
            else:
                verdict = "No clear evidence"
            
            # Extract explanation
            explanation_match = re.search(r"EXPLANATION:(.+?)$", result, re.DOTALL)
            if explanation_match:
                explanation = explanation_match.group(1).strip()
            else:
                explanation = "No clear explanation provided."
            
            # Extract source analyses
            source_analyses = {}
            source_pattern = r"SOURCE (\d+) ANALYSIS:(.+?)(?=SOURCE \d+ ANALYSIS:|VERDICT:|$)"
            matches = re.finditer(source_pattern, result, re.DOTALL)
            
            for match in matches:
                source_num = match.group(1)
                analysis = match.group(2).strip()
                source_analyses[f"source_{source_num}"] = analysis
            
            return {
                "verdict": verdict,
                "explanation": explanation,
                "source_analyses": source_analyses
            }
            
        except Exception as e:
            print(f"Error analyzing evidence with detail: {e}")
            return {
                "verdict": "No clear evidence",
                "explanation": "An error occurred while analyzing the evidence.",
                "source_analyses": {}
            }
