import requests
from bs4 import BeautifulSoup
import re
import json
from typing import List, Dict, Tuple, Optional
import os
from dotenv import load_dotenv
from evidence_analyzer import EvidenceAnalyzer

# Import optional modules if they exist
try:
    from text_processor import TextProcessor
except ImportError:
    TextProcessor = None

try:
    from advanced_search import AdvancedSearch
except ImportError:
    AdvancedSearch = None

# Load environment variables from .env file
load_dotenv()

# Load configuration from config.json
def load_config():
    try:
        with open('config.json', 'r') as f:
            return json.load(f)
    except:
        # Default configuration if file doesn't exist
        return {
            "trusted_sources": [
                "https://www.bbc.com/news",                # BBC News
                "https://www.reuters.com",                 # Reuters
                "https://www.thehindu.com",                # The Hindu
                "https://indianexpress.com",               # The Indian Express
                "https://pib.gov.in",                      # Press Information Bureau (PIB)
                "https://www.ndtv.com",                    # NDTV (stick to news reports, avoid op-eds)
                "https://www.theguardian.com/international",  # The Guardian (International)
                "https://www.aljazeera.com",               # Al Jazeera English
                "https://thewire.in",                      # The Wire
                "https://www.who.int/news-room",           # WHO (official health advisories)
            ],
            "settings": {
                "max_sources_to_check": 10,
                "max_articles_per_source": 5,
                "max_articles_to_analyze": 5,
                "content_extract_limit": 3000,
                "ai_model": "gpt-4"
            }
        }

# Load configuration
config = load_config()
TRUSTED_SOURCES = config["trusted_sources"]
SETTINGS = config["settings"]

class NewsAuthenticityDetector:
    """
    A class for detecting the authenticity of news claims based on trusted sources.
    """
    
    def __init__(self, trusted_sources: List[str]):
        """
        Initialize the detector with trusted sources.
        
        Args:            trusted_sources: List of URLs of trusted news sources
        """
        self.trusted_sources = trusted_sources
        
    def search_and_scrape(self, claim: str) -> List[Dict]:
        """
        Search for articles related to the claim and scrape their content.
        
        Args:
            claim: The claim to be verified
            
        Returns:
            List of dictionaries containing article information
        """
        # Extract keywords from the claim for search
        keywords = self._extract_keywords(claim)
        
        articles = []
        
        # For each trusted source, try to find relevant articles
        max_sources = SETTINGS.get("max_sources_to_check", 10)
        for source in self.trusted_sources[:max_sources]:
            try:
                source_articles = self._search_source(source, keywords)
                articles.extend(source_articles)
            except Exception as e:
                print(f"Error searching {source}: {e}")
                  # Limit to top most relevant articles
        max_articles = SETTINGS.get("max_articles_to_analyze", 5)
        return articles[:max_articles]
    
    def _extract_keywords(self, text: str) -> List[str]:
        """
        Extract important keywords from text for searching.
        
        Args:
            text: Text to extract keywords from
            
        Returns:
            List of keywords
        """        # Check if TextProcessor is available
        if TextProcessor:
            text_processor = TextProcessor()
            keywords = text_processor.extract_keywords(text)
            # Also extract named entities for better search results
            entities = text_processor.extract_named_entities(text)
        else:
            # Fallback to simple keyword extraction if TextProcessor is not available
            words = re.findall(r'\b[A-Za-z]{3,}\b', text)
            stop_words = ['and', 'the', 'with', 'that', 'this', 'for', 'from']
            keywords = [word.lower() for word in words if word.lower() not in stop_words]
            entities = []
        
        # Combine keywords and entities, remove duplicates
        all_terms = keywords + entities
        return list(set([term.lower() for term in all_terms if term]))  # Remove duplicates
    
    def _search_source(self, source_url: str, keywords: List[str]) -> List[Dict]:
        """
        Search a specific source for articles containing the keywords.
        
        Args:
            source_url: URL of the trusted source
            keywords: List of keywords to search for
            
        Returns:
            List of dictionaries with article information
        """
        # In a real implementation, you would use the search functionality of each site
        # or use a search engine API with site: operator
        # This is a simplified example that would need to be expanded
        
        articles = []
        
        try:
            # Get the homepage content
            response = requests.get(source_url, headers={'User-Agent': 'Mozilla/5.0'})
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Find links that might be news articles
            for link in soup.find_all('a', href=True):
                href = link['href']
                title = link.text.strip()
                
                # Skip empty titles or navigation links
                if not title or len(title) < 10:
                    continue
                
                # Check if the title contains any of our keywords
                if any(keyword in title.lower() for keyword in keywords):
                    # Ensure absolute URL
                    if not href.startswith('http'):
                        if href.startswith('/'):
                            base_url = '/'.join(source_url.split('/')[:3])  # Get domain
                            href = base_url + href
                        else:
                            href = source_url + '/' + href
                      # Add to our list of potential articles
                    articles.append({
                        'title': title,
                        'url': href,
                        'source': source_url
                    })
        
        except Exception as e:
            print(f"Error processing {source_url}: {e}")
        
        # Limit the number of articles per source
        max_articles_per_source = SETTINGS.get("max_articles_per_source", 5)
        return articles[:max_articles_per_source]
    
    def _scrape_article_content(self, url: str) -> str:
        """
        Scrape the content of an article.
        
        Args:
            url: URL of the article
            
        Returns:
            Article content as text
        """
        try:
            response = requests.get(url, headers={'User-Agent': 'Mozilla/5.0'})
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Remove tags that typically contain non-article content
            for tag in soup(['script', 'style', 'nav', 'header', 'footer', 'aside']):
                tag.decompose()
            
            # Extract paragraphs
            paragraphs = [p.text.strip() for p in soup.find_all('p') if p.text.strip()]
            
            content = '\n'.join(paragraphs)
            
            # Limit content length according to settings
            content_limit = SETTINGS.get("content_extract_limit", 3000)
            return content[:content_limit]
        
        except Exception as e:
            print(f"Error scraping {url}: {e}")
            return ""
    
    def evaluate_claim(self, claim: str) -> Dict:
        """
        Evaluate a claim by searching trusted sources and analyzing the evidence.
        
        Args:
            claim: The claim to be evaluated
            
        Returns:
            Dictionary with verdict, explanation, and sources
        """
        # Step 1: Search and scrape related articles
        related_articles = self.search_and_scrape(claim)
        
        if not related_articles:
            return {
                'verdict': 'No clear evidence',
                'explanation': 'No matching evidence found from trusted sources.',
                'sources': []
            }
          # Step 2: Extract content from the articles
        evidence = []
        for article in related_articles:
            content = self._scrape_article_content(article['url'])
            if content:
                evidence.append({
                    'title': article['title'],
                    'source': article['source'],
                    'url': article['url'],
                    'content': content[:3000]  # Limit content length
                })
        
        if not evidence:
            return {
                'verdict': 'No clear evidence',
                'explanation': 'No matching evidence found from trusted sources.',
                'sources': []
            }
        
        # Step 3: Use AI to analyze the evidence and reach a verdict
        verdict, explanation = self._analyze_evidence(claim, evidence)
        
        # Step 4: Format the result
        return {
            'verdict': verdict,
            'explanation': explanation,
            'sources': [{'title': e['title'], 'url': e['url']} for e in evidence]
        }
        
    def _analyze_evidence(self, claim: str, evidence: List[Dict]) -> Tuple[str, str]:
        """
        Use AI to analyze the evidence and determine if it supports, refutes, 
        or provides no clear position on the claim.
        
        Args:
            claim: The claim being evaluated
            evidence: List of dictionaries containing evidence
            
        Returns:
            Tuple of (verdict, explanation)
        """
        # Use the EvidenceAnalyzer to analyze the evidence
        analyzer = EvidenceAnalyzer(ai_model=SETTINGS.get("ai_model", "llama3-70b-8192"))
        return analyzer.analyze(claim, evidence)

    def format_output(self, result: Dict) -> str:
        """
        Format the evaluation result according to the specified output format.
        
        Args:
            result: Dictionary containing verdict, explanation, and sources
            
        Returns:
            Formatted output string
        """
        output = f"VERDICT: {result['verdict']}\n\n"
        output += f"EXPLANATION: {result['explanation']}\n\n"
        output += "SOURCES:\n"
        
        for source in result['sources']:
            output += f"- {source['title']} ({source['url']})\n"
        
        return output

# Example usage
def main():
    # Get Groq API key from environment variables or input
    if not os.getenv('GROQ_API_KEY'):
        api_key = input("Enter your Groq API key: ")
        os.environ['GROQ_API_KEY'] = api_key
    
    # Initialize the detector
    detector = NewsAuthenticityDetector(TRUSTED_SOURCES)
    
    # Get a claim to verify
    claim = input("Enter the news claim to verify: ")
    
    print("\nVerifying claim... (this may take a moment)")
    
    # Evaluate the claim
    result = detector.evaluate_claim(claim)
    
    # Format and print the output
    output = detector.format_output(result)
    print("\n" + "="*50 + "\n")
    print(output)

if __name__ == "__main__":
    main()
