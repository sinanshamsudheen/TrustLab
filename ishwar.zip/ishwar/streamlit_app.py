import streamlit as st
from news_authenticity_detector import NewsAuthenticityDetector, TRUSTED_SOURCES, SETTINGS, load_config
import os
import json
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Set page config
st.set_page_config(
    page_title="News Authenticity Detector",
    page_icon="📰",
    layout="wide"
)

# Title and description
st.title("📰 News Authenticity Detector")
st.markdown("""
This tool verifies news claims using trusted sources.
Enter a claim below to check its authenticity.
""")

# Sidebar with information
with st.sidebar:
    st.header("About")
    st.markdown("""
    This tool checks news claims against trusted sources including:
    - BBC News
    - Reuters
    - The Hindu
    - The Indian Express
    - PIB
    - NDTV    - The Guardian
    - Al Jazeera
    - The Wire
    - WHO
    """)
    
    st.header("How it works")
    st.markdown("""
    1. Enter your claim
    2. The tool searches trusted sources
    3. It analyzes the evidence
    4. It provides a verdict with explanation
    """)
    
    # Check if Groq API key is set in environment
    api_key_exists = bool(os.getenv('GROQ_API_KEY'))
    if not api_key_exists:
        st.error("Groq API key not found in .env file.")
        st.info("Please add your Groq API key to the .env file to use this application.")

# Create tabs
tab1, tab2, tab3 = st.tabs(["Verify Claim", "View Sources", "Settings"])

# Tab 1: Verify Claim
with tab1:
    # User input
    claim = st.text_area("Enter the news claim to verify:", height=100)
      # Process button
    if st.button("Verify Claim", type="primary", disabled=not api_key_exists):
        if not claim:
            st.error("Please enter a claim to verify.")
        else:
            with st.spinner("Verifying claim... (this may take a moment)"):
                try:
                    # Initialize the detector
                    detector = NewsAuthenticityDetector(TRUSTED_SOURCES)
                    
                    # Evaluate the claim
                    result = detector.evaluate_claim(claim)
                    
                    # Display the result
                    if result['verdict'] == "Supported":
                        verdict_color = "green"
                    elif result['verdict'] == "Refuted":
                        verdict_color = "red"
                    else:
                        verdict_color = "orange"
                    
                    st.markdown(f"#### VERDICT: <span style='color:{verdict_color}'>{result['verdict']}</span>", unsafe_allow_html=True)
                    st.markdown(f"**EXPLANATION:** {result['explanation']}")
                    
                    # Store the result for the Sources tab
                    st.session_state.result = result
                
                except Exception as e:
                    st.error(f"An error occurred: {str(e)}")
                    st.info("Please check your Groq API key in the .env file and try again.")
    else:
        if not api_key_exists:
            st.warning("Please add your Groq API key to the .env file to continue.")

# Tab 2: View Sources
with tab2:
    if 'result' in st.session_state:
        st.header("Sources")
        
        if not st.session_state.result['sources']:
            st.info("No sources were found for this claim.")
        else:
            for i, source in enumerate(st.session_state.result['sources'], 1):
                st.markdown(f"### Source {i}")
                st.markdown(f"**Title:** {source['title']}")
                st.markdown(f"**URL:** [{source['url']}]({source['url']})")
                st.divider()
    else:
        st.info("Verify a claim first to see sources here.")

# Tab 3: Settings
with tab3:
    st.header("Configuration Settings")
    
    # Load the current config
    config = load_config()
    
    st.subheader("Trusted Sources")
    sources_text = st.text_area("Edit Trusted Sources", 
                              value="\n".join(config["trusted_sources"]),
                              height=200,
                              help="One URL per line")
    
    st.subheader("General Settings")
    col1, col2 = st.columns(2)
    
    with col1:
        max_sources = st.number_input("Max Sources to Check", 
                                    value=config["settings"]["max_sources_to_check"],
                                    min_value=1, max_value=20)
        max_articles_per_source = st.number_input("Max Articles per Source", 
                                                value=config["settings"]["max_articles_per_source"],
                                                min_value=1, max_value=20)
    
    with col2:
        max_articles = st.number_input("Max Articles to Analyze", 
                                     value=config["settings"]["max_articles_to_analyze"],
                                     min_value=1, max_value=20)
        content_limit = st.number_input("Content Extract Limit", 
                                      value=config["settings"]["content_extract_limit"],
                                      min_value=500, max_value=10000, step=500)
    
    st.subheader("AI Model Settings")
    ai_model = st.selectbox("AI Model", 
                          options=["gpt-3.5-turbo", "gpt-4"], 
                          index=0 if config["settings"]["ai_model"] == "gpt-3.5-turbo" else 1)
    
    if st.button("Save Configuration", type="primary"):
        try:
            # Update the config
            config["trusted_sources"] = [s.strip() for s in sources_text.split("\n") if s.strip()]
            config["settings"]["max_sources_to_check"] = max_sources
            config["settings"]["max_articles_per_source"] = max_articles_per_source
            config["settings"]["max_articles_to_analyze"] = max_articles
            config["settings"]["content_extract_limit"] = content_limit
            config["settings"]["ai_model"] = ai_model
            
            # Save to file
            with open("config.json", "w") as f:
                json.dump(config, f, indent=4)
            
            st.success("Configuration saved successfully!")
            
        except Exception as e:
            st.error(f"Error saving configuration: {e}")

# Footer
st.markdown("---")
st.caption("News Authenticity Detector - Helps verify news claims using trusted sources")
