# News Authenticity Detector

A Python tool for fact-checking news claims using trusted sources.

## Features

- Searches and scrapes content from trusted news sources
- Matches claims to relevant articles
- Evaluates claims based on evidence from trusted sources
- Provides a structured verdict with explanation and sources

## Trusted Sources

The tool checks claims against the following trusted sources:
- BBC News
- Reuters
- The Hindu
- The Indian Express
- Press Information Bureau (PIB)
- NDTV
- The Guardian
- Al Jazeera English
- The Wire
- WHO (official health advisories)

## Setup

1. Install the required dependencies:
   ```
   pip install -r requirements.txt
   ```

2. Create a `.env` file with your Groq API key:
   ```
   # Copy the example file
   cp .env.example .env
   # Edit the file and add your Groq API key
   ```

3. Run the tool:
   ```
   python news_authenticity_detector.py
   ```

## Usage

1. Run the script
2. Enter the news claim to verify when prompted
3. The tool will search trusted sources, analyze the evidence, and provide a verdict

## Output Format

```
VERDICT: {Supported / Refuted / No clear evidence}

EXPLANATION: {One or two sentences summarizing the key evidence for the verdict. Neutral tone.}

SOURCES:
- {Title or URL}
- {Title or URL}
```

## Extending the Tool

You can extend the list of trusted sources by modifying the `TRUSTED_SOURCES` list in the script.

## Dependencies

- requests: For making HTTP requests to news websites
- beautifulsoup4: For parsing HTML and extracting relevant content
- groq: For analyzing evidence using Groq's LLM API
- python-dotenv: For loading environment variables from .env file

## Note

This tool requires an active internet connection to search and scrape news sources, and a Groq API key to analyze the evidence.
