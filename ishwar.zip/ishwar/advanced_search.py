"""
Advanced search module for the News Authenticity Detector.
This module provides enhanced search capabilities for finding relevant articles.
"""

import requests
from bs4 import BeautifulSoup
from typing import List, Dict, Optional
import re
from urllib.parse import quote
import tldextract

class AdvancedSearch:
    """
    Advanced search functionality for finding relevant articles from trusted sources.
    """
    
    def __init__(self, user_agent: str = 'Mozilla/5.0'):
        """
        Initialize the advanced search module.
        
        Args:
            user_agent: User-agent string for HTTP requests
        """
        self.user_agent = user_agent
        self.headers = {'User-Agent': user_agent}
    
    def search_with_site_operator(self, query: str, site: str) -> List[Dict]:
        """
        Search for articles on a specific site using a search engine with site: operator.
        
        Args:
            query: The search query
            site: The site to search within
            
        Returns:
            List of article information dictionaries
        """
        # Extract domain for the site operator
        ext = tldextract.extract(site)
        domain = f"{ext.domain}.{ext.suffix}"
        
        # Construct search URL with site operator
        search_query = f"{query} site:{domain}"
        encoded_query = quote(search_query)
        search_url = f"https://www.google.com/search?q={encoded_query}"
        
        articles = []
        
        try:
            # Make the request
            response = requests.get(search_url, headers=self.headers)
            soup = BeautifulSoup(response.text, 'html.parser')
            
            # Extract search results
            for result in soup.select('div.g'):
                # Extract title and link
                title_elem = result.select_one('h3')
                link_elem = result.select_one('a')
                
                if title_elem and link_elem:
                    title = title_elem.text.strip()
                    link = link_elem.get('href', '')
                    
                    # Clean up link (Google search results often have redirects or tracking)
                    if link.startswith('/url?q='):
                        link = link.split('/url?q=')[1].split('&')[0]
                    
                    # Skip if not from our target domain
                    if domain not in link:
                        continue
                    
                    # Extract snippet if available
                    snippet_elem = result.select_one('div.VwiC3b')
                    snippet = snippet_elem.text.strip() if snippet_elem else ""
                    
                    articles.append({
                        'title': title,
                        'url': link,
                        'source': site,
                        'snippet': snippet
                    })
        
        except Exception as e:
            print(f"Error in search_with_site_operator for {site}: {e}")
        
        return articles
    
    def direct_site_search(self, query: str, site: str) -> List[Dict]:
        """
        Directly search a site's search functionality if available.
        
        Args:
            query: The search query
            site: The site to search
            
        Returns:
            List of article information dictionaries
        """
        articles = []
        
        # Map of domain to search URL pattern
        search_patterns = {
            'bbc.com': 'https://www.bbc.co.uk/search?q={query}',
            'reuters.com': 'https://www.reuters.com/search/news?blob={query}',
            'thehindu.com': 'https://www.thehindu.com/search/?q={query}',
            'indianexpress.com': 'https://indianexpress.com/?s={query}',
            'ndtv.com': 'https://www.ndtv.com/search?searchtext={query}',
            'theguardian.com': 'https://www.theguardian.com/search?q={query}',
            'aljazeera.com': 'https://www.aljazeera.com/search/{query}',
            'thewire.in': 'https://thewire.in/?s={query}',
            'who.int': 'https://www.who.int/search?query={query}'
        }
        
        # Extract domain
        ext = tldextract.extract(site)
        domain = f"{ext.domain}.{ext.suffix}"
        
        # If we have a search pattern for this domain
        if domain in search_patterns:
            try:
                # Construct search URL
                encoded_query = quote(query)
                search_url = search_patterns[domain].format(query=encoded_query)
                
                # Make the request
                response = requests.get(search_url, headers=self.headers)
                soup = BeautifulSoup(response.text, 'html.parser')
                
                # Site-specific result extraction
                if domain == 'bbc.com':
                    results = soup.select('.ssrcss-1020bd1-Stack')
                    for result in results:
                        link_elem = result.select_one('a')
                        if link_elem:
                            href = link_elem.get('href', '')
                            title = link_elem.text.strip()
                            if href and title and len(title) > 10:
                                if not href.startswith('http'):
                                    href = f"https://www.bbc.com{href}"
                                articles.append({
                                    'title': title,
                                    'url': href,
                                    'source': site
                                })
                
                # Add more site-specific extractors as needed
                # This is a simplified example that would need to be expanded
                
            except Exception as e:
                print(f"Error in direct_site_search for {site}: {e}")
        
        return articles
    
    def search_site(self, query: str, site: str) -> List[Dict]:
        """
        Search for articles on a site using multiple methods.
        
        Args:
            query: The search query
            site: The site to search
            
        Returns:
            Combined list of article information dictionaries
        """
        # Try direct site search first
        articles = self.direct_site_search(query, site)
        
        # If no results, try with search engine
        if not articles:
            articles = self.search_with_site_operator(query, site)
        
        return articles
