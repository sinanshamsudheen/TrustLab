# News Authenticity Detector Setup Script

Write-Host "Setting up News Authenticity Detector..." -ForegroundColor Green

# Create and activate virtual environment
Write-Host "Creating virtual environment..." -ForegroundColor Yellow
python -m venv venv
& .\venv\Scripts\Activate.ps1

# Install required packages
Write-Host "Installing dependencies..." -ForegroundColor Yellow
pip install -r requirements.txt

# Check for .env file
if (-not (Test-Path -Path ".env")) {
    Write-Host "Creating .env file..." -ForegroundColor Yellow
    Copy-Item -Path ".env.example" -Destination ".env"
    Write-Host "Please edit the .env file and add your Groq API key." -ForegroundColor Cyan
    notepad .env
}
else {
    Write-Host ".env file already exists." -ForegroundColor Green
}

Write-Host "`nSetup complete!" -ForegroundColor Green
Write-Host "`nTo run the command-line version:" -ForegroundColor Cyan
Write-Host "  python news_authenticity_detector.py" -ForegroundColor White
Write-Host "`nTo run the Streamlit interface:" -ForegroundColor Cyan
Write-Host "  streamlit run streamlit_app.py" -ForegroundColor White
Write-Host "`n"

# Ask user which version to run
$choice = Read-Host "Would you like to run the Streamlit interface now? (y/n)"

if ($choice -eq "y" -or $choice -eq "Y") {
    Write-Host "Starting Streamlit interface..." -ForegroundColor Yellow
    streamlit run streamlit_app.py
}
else {
    Write-Host "You can run the tool later using the commands shown above." -ForegroundColor Cyan
}

Write-Host "`nPress any key to continue..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
